public class Example2 {
    public static void main(String[] args) {
        int a = 3;
        int b = 7;
        int result = multiply(a, b);
        System.out.println(result);
    }

    public static int multiply(int x, int y) {
        return x * y;
    }
}
